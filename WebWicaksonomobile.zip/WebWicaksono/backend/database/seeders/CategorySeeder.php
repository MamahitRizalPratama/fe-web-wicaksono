<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Keripik',
                'slug' => 'keripik',
                'icon' => '🥔',
                'color' => '#F39C12',
                'is_active' => true,
            ],
            [
                'name' => 'Brownies',
                'slug' => 'brownies',
                'icon' => '🍫',
                'color' => '#8E44AD',
                'is_active' => true,
            ],
            [
                'name' => 'Bakpia',
                'slug' => 'bakpia',
                'icon' => '🥮',
                'color' => '#E67E22',
                'is_active' => true,
            ],
            [
                'name' => 'Pie',
                'slug' => 'pie',
                'icon' => '🥧',
                'color' => '#D35400',
                'is_active' => true,
            ],
            [
                'name' => 'Nastar',
                'slug' => 'nastar',
                'icon' => '🍪',
                'color' => '#F1C40F',
                'is_active' => true,
            ],
            [
                'name' => 'Souvenir',
                'slug' => 'souvenir',
                'icon' => '🎁',
                'color' => '#27AE60',
                'is_active' => true,
            ],
            [
                'name' => 'Minuman',
                'slug' => 'minuman',
                'icon' => '🥤',
                'color' => '#3498DB',
                'is_active' => true,
            ],
        ];

        foreach ($categories as $category) {
            Category::create($category);
        }
    }
}