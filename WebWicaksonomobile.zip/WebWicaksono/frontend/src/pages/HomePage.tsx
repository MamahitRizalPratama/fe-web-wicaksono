import { useState } from 'react';
import { categories, products, formatPrice } from '../data';
import ProductCard from '../components/ProductCard';
import type { Page } from '../App';

interface HomePageProps {
  navigate: (page: Page, data?: unknown) => void;
  onAddToCart: (product: unknown) => void;
}

export default function HomePage({ navigate, onAddToCart }: HomePageProps) {
  const [categoryStart, setCategoryStart] = useState(0);

  const renderCategory = (cat: typeof categories[number]) => (
    <button key={cat.id} onClick={() => navigate('catalog')} className="card-hover category-card" style={{
      background: 'white', border: 'none', borderRadius: 14, padding: '24px 16px',
      textAlign: 'center', cursor: 'pointer', boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
      transition: 'all 0.25s',
    }}>
      <div style={{
        width: 60, height: 60, borderRadius: 16, margin: '0 auto 12px',
        background: `${cat.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28,
      }}>{cat.icon}</div>
      <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#1F2937' }}>{cat.name}</div>
      <div style={{ fontSize: '0.75rem', color: '#9CA3AF', marginTop: 4 }}>{cat.count} produk</div>
    </button>
  );

  return (
    <div>
      {/* Hero */}
      <section className="batik-bg home-hero" style={{
        background: 'linear-gradient(135deg, #FFF8F0 0%, #FFF3E8 50%, #FEFCE8 100%)',
        padding: '80px 24px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Decorative circles */}
        <div style={{ position: 'absolute', top: -80, right: -80, width: 320, height: 320, borderRadius: '50%', background: 'rgba(249,115,22,0.08)', zIndex: 0 }} />
        <div style={{ position: 'absolute', bottom: -60, left: -60, width: 240, height: 240, borderRadius: '50%', background: 'rgba(22,163,74,0.08)', zIndex: 0 }} />
        <div style={{ position: 'absolute', top: '30%', left: '40%', width: 160, height: 160, borderRadius: '50%', background: 'rgba(250,204,21,0.1)', zIndex: 0 }} />

        <div style={{ maxWidth: 1280, margin: '0 auto', position: 'relative', zIndex: 1 }}>
          <div className="home-hero-layout" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60, alignItems: 'center' }}>
            {/* Text */}
            <div className="fade-in">
              {/* Badge */}
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8,
                background: 'rgba(249,115,22,0.1)', borderRadius: 100,
                padding: '6px 14px', marginBottom: 20, border: '1px solid rgba(249,115,22,0.2)' }}>
                <span style={{ animation: 'pulse-dot 2s infinite', display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: '#F97316' }} />
                <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#F97316' }}>Terpercaya sejak 2005</span>
              </div>

              <h1 style={{
                fontSize: 'clamp(2rem, 4vw, 3.2rem)', fontWeight: 900, color: '#1F2937',
                lineHeight: 1.15, margin: '0 0 20px',
              }}>
                Pusat Oleh-Oleh{' '}
                <span style={{
                  color: '#F97316',
                  position: 'relative', display: 'inline-block',
                }}>
                  Khas Malang
                  <svg style={{ position: 'absolute', bottom: -4, left: 0, width: '100%' }} viewBox="0 0 200 8" preserveAspectRatio="none">
                    <path d="M0,6 Q50,0 100,6 Q150,12 200,6" stroke="#FACC15" strokeWidth="3" fill="none" strokeLinecap="round" />
                  </svg>
                </span>
              </h1>

              <p className="home-hero-description" style={{ fontSize: '1.05rem', color: '#4B5563', lineHeight: 1.75, margin: '0 0 32px', maxWidth: 460 }}>
                Temukan berbagai oleh-oleh khas Malang yang lezat dan autentik. Dari keripik tempe hingga apel segar, kami hadirkan cita rasa terbaik langsung ke pintumu.
              </p>

              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 40 }}>
                <button className="btn-primary" onClick={() => navigate('catalog')} style={{ padding: '14px 28px', fontSize: '0.95rem' }}>
                  🛒 Belanja Sekarang
                </button>
                <button className="btn-outline" style={{ padding: '14px 28px', fontSize: '0.95rem' }}>
                  Lihat Promo
                </button>
              </div>

            </div>

            {/* Hero Image Collage */}
            <div className="hero-collage" style={{ position: 'relative', height: 460 }}>
              <div className="hero-collage-main" style={{ position: 'absolute', top: 0, left: 20, width: 240, height: 300, borderRadius: 20, overflow: 'hidden', boxShadow: '0 16px 40px rgba(249,115,22,0.2)' }}>
                <img src="/public/kripikhome.png" alt="Keripik Malang" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(249,115,22,0.2), transparent)' }} />
              </div>
              <div className="hero-collage-top" style={{ position: 'absolute', top: -40, right: 80, width: 200, height: 240, borderRadius: 20, overflow: 'hidden', boxShadow: '0 16px 40px rgba(22,163,74,0.2)' }}>
                <img src="/public/kprkapel.png" alt="Apel Malang" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
              <div className="hero-collage-bottom" style={{ position: 'absolute', bottom: -40, right: 90, width: 220, height: 200, borderRadius: 20, overflow: 'hidden', boxShadow: '0 16px 40px rgba(250,204,21,0.25)' }}>
                <img src="/public/bakpia.jpeg" alt="Bakpia" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
            </div>
            <div className="hero-badges" style={{
              display: 'flex', justifyContent: 'center', gap: 12, marginTop: -8, flexWrap: 'wrap',
            }}>
              <div style={{
                background: 'white', borderRadius: 12, padding: '12px 16px',
                boxShadow: '0 8px 24px rgba(0,0,0,0.1)',
                display: 'flex', alignItems: 'center', gap: 10,
                border: '1px solid rgba(249,115,22,0.15)',
              }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(249,115,22,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>📦</div>
                <div>
                  <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#1F2937' }}>Pengiriman Cepat</div>
                  <div style={{ fontSize: '0.65rem', color: '#6B7280' }}>Seluruh Indonesia</div>
                </div>
              </div>
              <div style={{
                background: 'linear-gradient(135deg, #F97316, #EA6C0A)', borderRadius: 12, padding: '12px 16px',
                boxShadow: '0 8px 24px rgba(249,115,22,0.3)',
                display: 'flex', alignItems: 'center', gap: 10, color: 'white',
              }}>
                <span style={{ fontSize: 20 }}>⭐</span>
                <div>
                  <div style={{ fontSize: '0.75rem', fontWeight: 700 }}>Terlaris hari ini</div>
                  <div style={{ fontSize: '0.65rem', opacity: 0.85 }}>Apel Malang Premium</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust bar */}
      <div style={{ background: 'white', borderBottom: '1px solid rgba(0,0,0,0.06)', borderTop: '1px solid rgba(0,0,0,0.06)' }}>
        <div className="trust-grid" style={{ maxWidth: 1280, margin: '0 auto', padding: '16px 24px', display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap', gap: 16 }}>
          {[
            { icon: '🚚', title: 'Gratis Ongkir', sub: 'Pembelian min. Rp 100.000' },
            { icon: '✅', title: 'Produk Terjamin', sub: 'Sertifikat BPOM & Halal' },
            { icon: '🔄', title: 'Mudah Dikembalikan', sub: 'Garansi 7 hari' },
            { icon: '🔒', title: 'Pembayaran Aman', sub: 'SSL terenkripsi' },
          ].map(({ icon, title, sub }) => (
            <div key={title} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 24 }}>{icon}</span>
              <div>
                <div style={{ fontWeight: 700, fontSize: '0.85rem', color: '#1F2937' }}>{title}</div>
                <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>{sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Categories */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '64px 24px 32px' }}>
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#F97316', textTransform: 'uppercase', letterSpacing: 2 }}>Kategori</span>
          <h2 style={{ fontSize: '2rem', fontWeight: 800, color: '#1F2937', margin: '8px 0' }}>Jelajahi Pilihan Kami</h2>
          <p style={{ color: '#6B7280', maxWidth: 480, margin: '0 auto' }}>Berbagai kategori oleh-oleh khas Malang untuk memenuhi semua selera</p>
        </div>
        <div className="category-desktop">
          {categories.slice(categoryStart, categoryStart + 3).map(renderCategory)}
        </div>
        {categories.length > 3 && (
          <button
            className="category-more-button btn-outline"
            onClick={() => setCategoryStart(start => start + 3 >= categories.length ? 0 : start + 3)}
            aria-label="Lihat kategori berikutnya"
            title="Lihat kategori berikutnya"
          >
            &gt;
          </button>
        )}
        <div className="category-mobile">
          {categories.map(renderCategory)}
        </div>
      </section>

      {/* Best Sellers */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32, flexWrap: 'wrap', gap: 12 }}>
          <div>
            <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#F97316', textTransform: 'uppercase', letterSpacing: 2 }}>Terlaris</span>
          </div>
          <button onClick={() => navigate('catalog')} className="btn-outline" style={{ padding: '10px 20px', fontSize: '0.85rem' }}>
            Lihat Semua →
          </button>
        </div>
        <div className="product-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 20 }}>
          {products.map(p => (
            <ProductCard key={p.id} product={p} navigate={navigate} onAddToCart={onAddToCart as (product: unknown) => void} />
          ))}
        </div>
      </section>

      {/* Promo Banner */}
      <section style={{ maxWidth: 1280, margin: '32px auto', padding: '0 24px' }}>
        <div className="promo-layout" style={{ borderRadius: 20, overflow: 'hidden', display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
          {/* Left promo */}
          <div style={{
            background: 'linear-gradient(135deg, #16A34A 0%, #15803D 100%)',
            padding: '40px', display: 'flex', flexDirection: 'column', justifyContent: 'center',
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ position: 'absolute', top: -40, right: -40, width: 160, height: 160, borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
            <div style={{ position: 'relative', zIndex: 1 }}>
              <div style={{ background: '#FACC15', color: '#1F2937', fontSize: '0.75rem', fontWeight: 700, padding: '4px 12px', borderRadius: 100, display: 'inline-block', marginBottom: 12 }}>
                ⚡ PROMO SPESIAL
              </div>
              <h3 style={{ color: 'white', fontSize: '1.6rem', fontWeight: 800, margin: '0 0 8px', lineHeight: 1.2 }}>
                Diskon 30%<br />Pembelian Pertama
              </h3>
              <p style={{ color: 'rgba(255,255,255,0.8)', margin: '0 0 20px', fontSize: '0.875rem' }}>
                Gunakan kode: <strong>MALANG30</strong>
              </p>
              <button className="btn-primary" onClick={() => navigate('catalog')} style={{ padding: '12px 24px' }}>
                Klaim Sekarang
              </button>
            </div>
          </div>
          {/* Right promo */}
          <div style={{
            background: 'linear-gradient(135deg, #F97316 0%, #EA6C0A 100%)',
            padding: '40px', display: 'flex', flexDirection: 'column', justifyContent: 'center',
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ position: 'absolute', bottom: -40, left: -40, width: 160, height: 160, borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
            <div style={{ position: 'relative', zIndex: 1 }}>
              <div style={{ background: 'white', color: '#F97316', fontSize: '0.75rem', fontWeight: 700, padding: '4px 12px', borderRadius: 100, display: 'inline-block', marginBottom: 12 }}>
                🚚 GRATIS ONGKIR
              </div>
              <h3 style={{ color: 'white', fontSize: '1.6rem', fontWeight: 800, margin: '0 0 8px', lineHeight: 1.2 }}>
                Kirim ke Seluruh<br />Indonesia
              </h3>
              <p style={{ color: 'rgba(255,255,255,0.8)', margin: '0 0 20px', fontSize: '0.875rem' }}>
                Minimum pembelian Rp 100.000
              </p>
              <button style={{
                background: 'white', color: '#F97316', border: 'none', borderRadius: 10,
                padding: '12px 24px', fontFamily: 'Poppins, sans-serif', fontWeight: 700,
                cursor: 'pointer', transition: 'transform 0.2s',
              }}
              onClick={() => navigate('catalog')}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; }}>
                Belanja Sekarang
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Google Maps reviews */}
      <section style={{ background: 'white', padding: '64px 24px', marginTop: 40 }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#F97316', textTransform: 'uppercase', letterSpacing: 2 }}>Google Maps</span>
            <h2 style={{ fontSize: '2rem', fontWeight: 800, color: '#1F2937', margin: '8px 0' }}>Ulasan Pelanggan</h2>
            <p style={{ color: '#6B7280', maxWidth: 480, margin: '0 auto' }}>Lihat rating dan ulasan terbaru Wicaksono langsung dari Google Maps</p>
          </div>

          <div className="home-review-layout" style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 24, alignItems: 'stretch' }}>
            <div className="home-map-frame" style={{ minHeight: 320, borderRadius: 16, overflow: 'hidden', boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.5282515022604!2d112.63468171083817!3d-7.944234979102484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd629c24db45ef3%3A0xe58463eb721e5be0!2sWicaksono%20Pusat%20Oleh-oleh%20Khas%20Malang!5e0!3m2!1sid!2sid!4v1787940602474!5m2!1sid!2sid"
                title="Ulasan Wicaksono di Google Maps"
                width="100%"
                height="100%"
                style={{ border: 0, width: '100%', height: '100%', display: 'block' }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <div className="home-review-card" style={{ background: '#FFF8F0', borderRadius: 16, padding: 28, display: 'flex', flexDirection: 'column', justifyContent: 'center', border: '1px solid rgba(249,115,22,0.12)' }}>
              <div style={{ fontSize: 42, marginBottom: 12 }}>★</div>
              <h3 style={{ margin: '0 0 10px', color: '#1F2937', fontSize: '1.25rem' }}>Ulasan terbaru</h3>
              <p style={{ margin: '0 0 24px', color: '#6B7280', fontSize: '0.9rem', lineHeight: 1.7 }}>
                Rating dan pengalaman pelanggan ditampilkan langsung dari halaman Google Maps Wicaksono.
              </p>
              <a
                href="https://www.google.com/maps/search/?api=1&query=Wicaksono%20Pusat%20Oleh-oleh%20Khas%20Malang"
                target="_blank"
                rel="noreferrer"
                className="btn-primary"
                style={{ display: 'inline-flex', justifyContent: 'center', textDecoration: 'none', padding: '12px 18px' }}
              >
                Lihat Ulasan di Google Maps
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
