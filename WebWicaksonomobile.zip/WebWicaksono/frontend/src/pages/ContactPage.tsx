import type { Page } from '../App';
import { useState } from 'react';

interface ContactPageProps {
  navigate: (page: Page, data?: unknown) => void;
}

export default function ContactPage({ navigate }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Di sini Anda bisa menambahkan logika untuk mengirim email atau menyimpan data
    console.log('Form data:', formData);
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className="mobile-page" style={{ maxWidth: 1280, margin: '0 auto', padding: '60px 24px' }}>
      <h1 style={{
        fontSize: '2.5rem',
        fontWeight: 900,
        color: '#1F2937',
        marginBottom: 8,
        textAlign: 'center'
      }}>
        Hubungi Kami
      </h1>
      <p style={{
        textAlign: 'center',
        color: '#6B7280',
        fontSize: '1rem',
        marginBottom: 48
      }}>
        Ada pertanyaan? Kami siap membantu Anda!
      </p>

      <div className="contact-layout" style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 48,
        alignItems: 'start'
      }}>
        {/* Informasi Kontak */}
        <div>
          <h2 style={{
            fontSize: '1.5rem',
            fontWeight: 800,
            color: '#1F2937',
            marginBottom: 24
          }}>
            Informasi Kontak
          </h2>

          {/* Alamat */}
          <div className="contact-info-card" style={{
            display: 'flex',
            gap: 16,
            marginBottom: 24,
            padding: 20,
            background: '#FFF8F0',
            borderRadius: 12,
            border: '1px solid rgba(249,115,22,0.12)'
          }}>
            <div style={{
              width: 48,
              height: 48,
              borderRadius: 12,
              background: 'rgba(249,115,22,0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 24,
              flexShrink: 0
            }}>
              📍
            </div>
            <div>
              <div style={{ fontWeight: 700, color: '#1F2937', marginBottom: 4 }}>
                Alamat Toko
              </div>
              <div style={{ color: '#6B7280', fontSize: '0.9rem', lineHeight: 1.6 }}>
                Jl. Candi Agung II No.1, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65142<br />
              </div>
            </div>
          </div>

          {/* Telepon */}
          <div className="contact-info-card" style={{
            display: 'flex',
            gap: 16,
            marginBottom: 24,
            padding: 20,
            background: '#FFF8F0',
            borderRadius: 12,
            border: '1px solid rgba(249,115,22,0.12)'
          }}>
            <div style={{
              width: 48,
              height: 48,
              borderRadius: 12,
              background: 'rgba(249,115,22,0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 24,
              flexShrink: 0
            }}>
              📞
            </div>
            <div>
              <div style={{ fontWeight: 700, color: '#1F2937', marginBottom: 4 }}>
                Telepon
              </div>
              <div style={{ color: '#6B7280', fontSize: '0.9rem' }}>
                +6282264774945
              </div>
              {/* <div style={{ color: '#6B7280', fontSize: '0.9rem' }}>
                +62 21-1234-5678
              </div> */}
            </div>
          </div>

          {/* Email */}
          <div className="contact-info-card" style={{
            display: 'flex',
            gap: 16,
            marginBottom: 24,
            padding: 20,
            background: '#FFF8F0',
            borderRadius: 12,
            border: '1px solid rgba(249,115,22,0.12)'
          }}>
            <div style={{
              width: 48,
              height: 48,
              borderRadius: 12,
              background: 'rgba(249,115,22,0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 24,
              flexShrink: 0
            }}>
              ✉️
            </div>
            <div>
              <div style={{ fontWeight: 700, color: '#1F2937', marginBottom: 4 }}>
                Email
              </div>
              <div style={{ color: '#6B7280', fontSize: '0.9rem' }}>
                info@wicaksono.com
              </div>
              {/* <div style={{ color: '#6B7280', fontSize: '0.9rem' }}>
                cs@wicaksono.com
              </div> */}
            </div>
          </div>

          {/* Jam Operasional */}
          <div className="contact-info-card" style={{
            display: 'flex',
            gap: 16,
            padding: 20,
            background: '#FFF8F0',
            borderRadius: 12,
            border: '1px solid rgba(249,115,22,0.12)'
          }}>
            <div style={{
              width: 48,
              height: 48,
              borderRadius: 12,
              background: 'rgba(249,115,22,0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 24,
              flexShrink: 0
            }}>
              🕐
            </div>
            <div>
              <div style={{ fontWeight: 700, color: '#1F2937', marginBottom: 4 }}>
                Jam Operasional
              </div>
              <div style={{ color: '#6B7280', fontSize: '0.9rem' }}>
                Senin - Minggu: 07.00 - 21.00
              </div>
              {/* <div style={{ color: '#6B7280', fontSize: '0.9rem' }}>
                Minggu & Hari Libur: 09.00 - 18.00
              </div> */}
            </div>
          </div>
        </div>

        {/* Form Kontak */}
        <div>
          <h2 style={{
            fontSize: '1.5rem',
            fontWeight: 800,
            color: '#1F2937',
            marginBottom: 24
          }}>
            Kirim Pesan
          </h2>

          {isSubmitted && (
            <div style={{
              background: '#DCFCE7',
              color: '#16A34A',
              padding: '12px 16px',
              borderRadius: 8,
              marginBottom: 16,
              fontWeight: 600
            }}>
              ✅ Pesan berhasil dikirim!
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 16 }}>
              <label style={{
                display: 'block',
                fontWeight: 600,
                fontSize: '0.85rem',
                color: '#374151',
                marginBottom: 6
              }}>
                Nama Lengkap
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  borderRadius: 10,
                  border: '1.5px solid #E5E7EB',
                  fontFamily: 'Poppins, sans-serif',
                  fontSize: '0.95rem',
                  transition: 'border-color 0.2s',
                  outline: 'none',
                  background: 'white'
                }}
                onFocus={(e) => e.target.style.borderColor = '#F97316'}
                onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
                placeholder="Masukkan nama Anda"
              />
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{
                display: 'block',
                fontWeight: 600,
                fontSize: '0.85rem',
                color: '#374151',
                marginBottom: 6
              }}>
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  borderRadius: 10,
                  border: '1.5px solid #E5E7EB',
                  fontFamily: 'Poppins, sans-serif',
                  fontSize: '0.95rem',
                  transition: 'border-color 0.2s',
                  outline: 'none',
                  background: 'white'
                }}
                onFocus={(e) => e.target.style.borderColor = '#F97316'}
                onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
                placeholder="Masukkan email Anda"
              />
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{
                display: 'block',
                fontWeight: 600,
                fontSize: '0.85rem',
                color: '#374151',
                marginBottom: 6
              }}>
                Subjek
              </label>
              <input
                type="text"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                required
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  borderRadius: 10,
                  border: '1.5px solid #E5E7EB',
                  fontFamily: 'Poppins, sans-serif',
                  fontSize: '0.95rem',
                  transition: 'border-color 0.2s',
                  outline: 'none',
                  background: 'white'
                }}
                onFocus={(e) => e.target.style.borderColor = '#F97316'}
                onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
                placeholder="Masukkan subjek pesan"
              />
            </div>

            <div style={{ marginBottom: 20 }}>
              <label style={{
                display: 'block',
                fontWeight: 600,
                fontSize: '0.85rem',
                color: '#374151',
                marginBottom: 6
              }}>
                Pesan
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={5}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  borderRadius: 10,
                  border: '1.5px solid #E5E7EB',
                  fontFamily: 'Poppins, sans-serif',
                  fontSize: '0.95rem',
                  transition: 'border-color 0.2s',
                  outline: 'none',
                  background: 'white',
                  resize: 'vertical'
                }}
                onFocus={(e) => e.target.style.borderColor = '#F97316'}
                onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
                placeholder="Tulis pesan Anda di sini..."
              />
            </div>

            <button
              type="submit"
              style={{
                width: '100%',
                padding: '14px',
                background: 'linear-gradient(135deg, #F97316, #EA6C0A)',
                color: 'white',
                border: 'none',
                borderRadius: 10,
                fontSize: '1rem',
                fontWeight: 700,
                cursor: 'pointer',
                transition: 'transform 0.2s, box-shadow 0.2s',
                fontFamily: 'Poppins, sans-serif'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 8px 24px rgba(249,115,22,0.3)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              Kirim Pesan
            </button>
          </form>
        </div>
      </div>

      {/* Map */}
      <div style={{ marginTop: 60 }}>
        <h2 style={{
          fontSize: '1.5rem',
          fontWeight: 800,
          color: '#1F2937',
          marginBottom: 24,
          textAlign: 'center'
        }}>
          Lokasi Kami
        </h2>
        <div className="contact-map" style={{
          borderRadius: 16,
          overflow: 'hidden',
          boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
          height: 400
        }}>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.5282515022604!2d112.63468171083817!3d-7.944234979102484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd629c24db45ef3%3A0xe58463eb721e5be0!2sWicaksono%20Pusat%20Oleh-oleh%20Khas%20Malang!5e0!3m2!1sid!2sid!4v1787940602474!5m2!1sid!2sid"
            title="Lokasi Toko Wicaksono"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </div>
  );
}