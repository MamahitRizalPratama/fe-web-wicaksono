import { useEffect, useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import * as XLSX from 'xlsx-js-style';
import { formatPrice } from '../data';
import { apiFetch, storageUrl } from '../api/client';
import type { Page } from '../App';

interface AdminProduct {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  sold: number;
  stock: number;
  discount: number;
  image: string;
  description: string;
  tags: string[];
}

interface DashboardSummary {
  total_products: number;
  total_orders: number;
  total_revenue: number;
  total_users: number;
}

interface MonthlySale {
  key: string;
  month: string;
  revenue: number;
  orders: number;
}

interface CategorySale {
  name: string;
  sales: number;
}

interface AdminOrder {
  id: number;
  order_number: string;
  customer: string;
  date: string;
  items: number;
  total: number;
  status: string;
}

interface AdminOrderDetail extends AdminOrder {
  subtotal?: number;
  shipping_cost?: number;
  shipping_name?: string;
  shipping_phone?: string;
  shipping_province?: string;
  shipping_city?: string;
  shipping_postal_code?: string;
  shipping_address?: string;
  shipping_method?: { name?: string };
  payment?: { method?: string; status?: string };
  items_detail: Array<{ id: number; product_name: string; quantity: number; price: number; subtotal: number }>;
}

interface AdminUser {
  id: number;
  name: string;
  email: string;
  phone?: string | null;
  role: string;
  orders_count: number;
  reviews_count: number;
  addresses_count: number;
  created_at?: string;
}

interface AdminUserDetail extends AdminUser {
  addresses?: Array<{ id: number; label?: string; address?: string; city?: string }>;
  orders?: Array<{
    id: number;
    order_number: string;
    total: number;
    order_status?: { value?: string } | string;
    created_at?: string;
  }>;
}

const normalizeProduct = (item: any): AdminProduct => ({
  id: Number(item.id),
  name: item.name,
  category: item.category?.name || item.category || 'lainnya',
  price: Number(item.price || 0),
  originalPrice: Number(item.original_price ?? item.price ?? 0),
  rating: Number(item.rating ?? 0),
  reviews: Number(item.review_count ?? 0),
  sold: Number(item.sold ?? 0),
  stock: Number(item.stock ?? 0),
  discount: Number(item.discount ?? 0),
  image: storageUrl(item.image || item.images?.find((img: any) => img.is_primary)?.path || item.images?.[0]?.path || null),
  description: item.description || '',
  tags: ['baru', 'premium'],
});

const normalizeOrder = (item: any): AdminOrder => ({
  id: Number(item.id),
  order_number: item.order_number,
  customer: item.user?.name || item.shipping_name || 'Pelanggan',
  date: item.created_at ? new Intl.DateTimeFormat('id-ID').format(new Date(item.created_at)) : '-',
  items: Array.isArray(item.items) ? item.items.reduce((total: number, orderItem: any) => total + Number(orderItem.quantity || 0), 0) : 0,
  total: Number(item.total || 0),
  status: item.order_status?.value || item.order_status || 'pending',
});

export default function AdminPage({ navigate }: { navigate: (page: Page) => void }) {
  const [activeMenu, setActiveMenu] = useState('dashboard');
  const [productList, setProductList] = useState<AdminProduct[]>([]);
  const [categories, setCategories] = useState<{ id: number; name: string }[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [newProduct, setNewProduct] = useState({
    name: '',
    categoryId: '',
    price: '',
    stock: '',
    description: '',
  });
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [dashboardSummary, setDashboardSummary] = useState<DashboardSummary | null>(null);
  const [monthlySales, setMonthlySales] = useState<MonthlySale[]>([]);
  const [categorySales, setCategorySales] = useState<CategorySale[]>([]);
  const [adminOrders, setAdminOrders] = useState<AdminOrder[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<AdminOrderDetail | null>(null);
  const [isLoadingOrderDetail, setIsLoadingOrderDetail] = useState(false);
  const [isUpdatingOrderStatus, setIsUpdatingOrderStatus] = useState(false);
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>([]);
  const [selectedUser, setSelectedUser] = useState<AdminUserDetail | null>(null);
  const [settings, setSettings] = useState(() => ({
    storeName: localStorage.getItem('storeName') || 'Wicaksono',
    storeEmail: localStorage.getItem('storeEmail') || 'admin@wicaksono.id',
    storePhone: localStorage.getItem('storePhone') || '',
    storeAddress: localStorage.getItem('storeAddress') || '',
    adminName: localStorage.getItem('adminName') || 'Admin',
  }));
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const response = await apiFetch<{ data?: Array<{ id: number; name: string }> }>('/categories');
        const categoryList = response.data ?? [];
        setCategories(categoryList);

        if (!newProduct.categoryId && categoryList[0]) {
          setNewProduct(prev => ({ ...prev, categoryId: String(categoryList[0].id) }));
        }
      } catch (error) {
        console.error('Gagal memuat kategori:', error);
      }
    };

    const loadProducts = async () => {
      try {
        const response = await apiFetch<{ data?: any[] }>('/products');
        const items = response.data ?? [];
        setProductList(items.map(normalizeProduct));
      } catch (error) {
        console.error('Gagal memuat produk:', error);
      }
    };

    loadCategories();
    loadProducts();
  }, [newProduct.categoryId]);

  useEffect(() => {
    const loadDashboardSummary = async () => {
      try {
        const response = await apiFetch<{ data?: { summary?: DashboardSummary; monthly_sales?: MonthlySale[]; category_sales?: CategorySale[] } }>('/admin/dashboard');
        setDashboardSummary(response.data?.summary ?? null);
        setMonthlySales(response.data?.monthly_sales ?? []);
        setCategorySales(response.data?.category_sales ?? []);
      } catch (error) {
        console.error('Gagal memuat ringkasan dashboard:', error);
      }
    };

    loadDashboardSummary();
  }, []);

  useEffect(() => {
    const loadOrders = async () => {
      try {
        const response = await apiFetch<{ data?: any[] }>('/admin/orders?per_page=100');
        setAdminOrders((response.data ?? []).map(normalizeOrder));
      } catch (error) {
        console.error('Gagal memuat pesanan admin:', error);
      }
    };

    loadOrders();
  }, []);

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const response = await apiFetch<{ data?: AdminUser[] }>('/admin/users?per_page=100');
        setAdminUsers(response.data ?? []);
      } catch (error) {
        console.error('Gagal memuat data pengguna:', error);
      }
    };

    loadUsers();
  }, []);

  const statusColor = (s: string) => ({
    pending: { bg: '#FEF3C7', text: '#D97706' },
    confirmed: { bg: '#DBEAFE', text: '#1D4ED8' },
    processing: { bg: '#FEF3C7', text: '#D97706' },
    shipped: { bg: '#DBEAFE', text: '#1D4ED8' },
    completed: { bg: '#DCFCE7', text: '#16A34A' },
    cancelled: { bg: '#FEE2E2', text: '#DC2626' },
    selesai: { bg: '#DCFCE7', text: '#16A34A' },
    dikirim: { bg: '#DBEAFE', text: '#1D4ED8' },
    diproses: { bg: '#FEF3C7', text: '#D97706' },
    batal: { bg: '#FEE2E2', text: '#DC2626' },
  }[s] ?? { bg: '#F3F4F6', text: '#6B7280' });

  const orderStatusLabel = (status: string) => ({
    pending: 'Menunggu',
    confirmed: 'Dikonfirmasi',
    processing: 'Diproses',
    shipped: 'Dikirim',
    completed: 'Selesai',
    cancelled: 'Dibatalkan',
  }[status] ?? status);

  const handleViewOrderDetail = async (order: AdminOrder) => {
    setIsLoadingOrderDetail(true);
    try {
      const response = await apiFetch<{ data?: any }>(`/admin/orders/${order.id}`);
      const detail = response.data;
      if (!detail) return;

      setSelectedOrder({
        ...order,
        subtotal: Number(detail.subtotal || 0),
        shipping_cost: Number(detail.shipping_cost || 0),
        shipping_name: detail.shipping_name,
        shipping_phone: detail.shipping_phone,
        shipping_province: detail.shipping_province,
        shipping_city: detail.shipping_city,
        shipping_postal_code: detail.shipping_postal_code,
        shipping_address: detail.shipping_address,
        shipping_method: detail.shipping_method,
        payment: detail.payment,
        items_detail: Array.isArray(detail.items) ? detail.items.map((item: any) => ({
          id: Number(item.id),
          product_name: item.product_name || item.product?.name || 'Produk',
          quantity: Number(item.quantity || 0),
          price: Number(item.price || 0),
          subtotal: Number(item.subtotal || 0),
        })) : [],
      });
    } catch (error) {
      window.alert(error instanceof Error ? error.message : 'Gagal memuat detail pesanan.');
    } finally {
      setIsLoadingOrderDetail(false);
    }
  };

  const handleUpdateOrderStatus = async (status: string) => {
    if (!selectedOrder || isUpdatingOrderStatus) return;

    setIsUpdatingOrderStatus(true);
    try {
      await apiFetch(`/admin/orders/${selectedOrder.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
      setAdminOrders(previous => previous.map(order => order.id === selectedOrder.id ? { ...order, status } : order));
      setSelectedOrder(previous => previous ? { ...previous, status } : previous);
      window.alert(`Status pesanan diperbarui menjadi ${orderStatusLabel(status)}.`);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : 'Gagal memperbarui status pesanan.');
    } finally {
      setIsUpdatingOrderStatus(false);
    }
  };

  const handleAddProductInput = (field: string, value: string) => {
    setNewProduct(prev => ({ ...prev, [field]: value }));
  };

  const openAddModal = () => {
    setEditingProductId(null);
    setNewProduct({ name: '', categoryId: categories[0]?.id ? String(categories[0].id) : '', price: '', stock: '', description: '' });
    setImagePreview(null);
    setImageFile(null);
    setShowAddModal(true);
  };

  const openEditModal = (product: AdminProduct) => {
    const category = categories.find(item => item.name.toLowerCase() === product.category.toLowerCase());
    setEditingProductId(product.id);
    setNewProduct({
      name: product.name,
      categoryId: category ? String(category.id) : '',
      price: String(product.price),
      stock: String(product.stock),
      description: product.description,
    });
    setImagePreview(product.image);
    setImageFile(null);
    setShowAddModal(true);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImageFile(file);

    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(typeof reader.result === 'string' ? reader.result : null);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProduct = async () => {
    if (!newProduct.name.trim() || !newProduct.price || !newProduct.stock || !newProduct.description.trim()) {
      window.alert('Mohon lengkapi semua field produk sebelum disimpan.');
      return;
    }

    if (!newProduct.categoryId) {
      window.alert('Pilih kategori terlebih dahulu.');
      return;
    }

    try {
      const formData = new FormData();
      formData.append('category_id', newProduct.categoryId);
      formData.append('name', newProduct.name.trim());
      formData.append('description', newProduct.description.trim());
      formData.append('price', String(Number(newProduct.price)));
      formData.append('original_price', String(Number(newProduct.price)));
      formData.append('stock', String(Number(newProduct.stock)));
      formData.append('discount', '0');
      formData.append('is_active', '1');

      if (imageFile) {
        formData.append('image', imageFile);
      }

      const endpoint = editingProductId ? `/admin/products/${editingProductId}` : '/admin/products';
      if (editingProductId) {
        formData.append('_method', 'PUT');
      }

      const response = await apiFetch<{ data?: any }>(endpoint, {
        method: 'POST',
        body: formData,
      });

      const saved = normalizeProduct(response.data ?? {});
      setProductList(prev => editingProductId
        ? prev.map(product => product.id === saved.id ? saved : product)
        : [saved, ...prev]);
      if (!editingProductId) {
        setDashboardSummary(prev => prev ? { ...prev, total_products: prev.total_products + 1 } : prev);
      }
      setNewProduct({ name: '', categoryId: categories[0]?.id ? String(categories[0].id) : '', price: '', stock: '', description: '' });
      setImagePreview(null);
      setImageFile(null);
      setShowAddModal(false);
      window.alert(editingProductId ? 'Produk berhasil diperbarui.' : 'Produk berhasil ditambahkan');
    } catch (error) {
      console.error('Gagal menambah produk:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal menambah produk.');
    }
  };

  const handleDeleteProduct = async (product: AdminProduct) => {
    if (!window.confirm(`Hapus produk "${product.name}"?`)) return;

    try {
      await apiFetch(`/admin/products/${product.id}`, { method: 'DELETE' });
      setProductList(prev => prev.filter(item => item.id !== product.id));
      setDashboardSummary(prev => prev ? { ...prev, total_products: Math.max(0, prev.total_products - 1) } : prev);
      window.alert('Produk berhasil dihapus.');
    } catch (error) {
      console.error('Gagal menghapus produk:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal menghapus produk.');
    }
  };

  const handleDeleteAllProducts = async () => {
    if (!productList.length) {
      window.alert('Tidak ada produk untuk dihapus.');
      return;
    }

    if (!window.confirm(`Hapus semua ${productList.length} produk? Data ini tidak dapat dikembalikan.`)) return;

    try {
      await apiFetch('/admin/products', { method: 'DELETE' });
      setProductList([]);
      setDashboardSummary(prev => prev ? { ...prev, total_products: 0 } : prev);
      window.alert('Semua produk berhasil dihapus.');
    } catch (error) {
      console.error('Gagal menghapus semua produk:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal menghapus semua produk.');
    }
  };

  const handleDeleteAllOrders = async () => {
    if (!adminOrders.length) {
      window.alert('Tidak ada pesanan untuk dihapus.');
      return;
    }

    if (!window.confirm(`Hapus semua ${adminOrders.length} pesanan lama? Data ini tidak dapat dikembalikan.`)) return;

    try {
      await apiFetch('/admin/orders', { method: 'DELETE' });
      setAdminOrders([]);
      setDashboardSummary(prev => prev ? { ...prev, total_orders: 0, total_revenue: 0 } : prev);
      window.alert('Semua pesanan berhasil dihapus.');
    } catch (error) {
      console.error('Gagal menghapus semua pesanan:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal menghapus semua pesanan.');
    }
  };

  const handleAddCategory = async () => {
    const name = window.prompt('Masukkan nama kategori baru:')?.trim();
    if (!name) return;

    try {
      const response = await apiFetch<{ data?: { id: number; name: string } }>('/admin/categories', {
        method: 'POST',
        body: JSON.stringify({ name }),
      });

      if (response.data) {
        setCategories(prev => [...prev, response.data as { id: number; name: string }]);
      }
      window.alert('Kategori berhasil ditambahkan.');
    } catch (error) {
      console.error('Gagal menambah kategori:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal menambah kategori.');
    }
  };

  const handleEditCategory = async (category: { id: number; name: string }) => {
    const name = window.prompt('Ubah nama kategori:', category.name)?.trim();
    if (!name || name === category.name) return;

    try {
      const response = await apiFetch<{ data?: { id: number; name: string } }>(`/admin/categories/${category.id}`, {
        method: 'PUT',
        body: JSON.stringify({ name }),
      });

      const updatedCategory = response.data ?? { ...category, name };
      setCategories(prev => prev.map(item => item.id === category.id ? updatedCategory : item));
      setProductList(prev => prev.map(product => product.category.toLowerCase() === category.name.toLowerCase()
        ? { ...product, category: updatedCategory.name }
        : product));
      window.alert('Kategori berhasil diperbarui.');
    } catch (error) {
      console.error('Gagal mengubah kategori:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal mengubah kategori.');
    }
  };

  const handleDeleteCategory = async (category: { id: number; name: string }) => {
    if (!window.confirm(`Hapus kategori "${category.name}"?`)) return;

    try {
      await apiFetch(`/admin/categories/${category.id}`, { method: 'DELETE' });
      setCategories(prev => prev.filter(item => item.id !== category.id));
      window.alert('Kategori berhasil dihapus.');
    } catch (error) {
      console.error('Gagal menghapus kategori:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal menghapus kategori.');
    }
  };

  const handleViewUserHistory = async (user: AdminUser) => {
    try {
      const response = await apiFetch<{ data?: AdminUserDetail }>(`/admin/users/${user.id}`);
      setSelectedUser(response.data ?? user);
    } catch (error) {
      console.error('Gagal memuat riwayat pengguna:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal memuat riwayat pengguna.');
    }
  };

  const handleDeleteUser = async (user: AdminUser) => {
    if (!window.confirm(`Hapus pengguna "${user.name}"? Data pengguna tidak dapat dikembalikan.`)) return;

    try {
      await apiFetch(`/admin/users/${user.id}`, { method: 'DELETE' });
      setAdminUsers(prev => prev.filter(item => item.id !== user.id));
      if (selectedUser?.id === user.id) setSelectedUser(null);
      window.alert('Pengguna berhasil dihapus.');
    } catch (error) {
      console.error('Gagal menghapus pengguna:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal menghapus pengguna.');
    }
  };

  const handleExportReport = () => {
    if (!productList.length && !adminOrders.length) {
      window.alert('Belum ada data laporan untuk diekspor.');
      return;
    }

    const border = {
      top: { style: 'thin', color: { rgb: 'D1D5DB' } },
      bottom: { style: 'thin', color: { rgb: 'D1D5DB' } },
      left: { style: 'thin', color: { rgb: 'D1D5DB' } },
      right: { style: 'thin', color: { rgb: 'D1D5DB' } },
    };
    const titleStyle = { font: { bold: true, color: { rgb: 'FFFFFF' }, sz: 14 }, fill: { fgColor: { rgb: '1F2937' } }, alignment: { horizontal: 'center' }, border };
    const headerStyle = { font: { bold: true, color: { rgb: 'FFFFFF' } }, fill: { fgColor: { rgb: 'F97316' } }, alignment: { horizontal: 'center', vertical: 'center', wrapText: true }, border };
    const dataStyle = { border, alignment: { vertical: 'center' } };

    const createSheet = (title: string, headers: string[], rows: unknown[][], widths: number[]) => {
      const sheet = XLSX.utils.aoa_to_sheet([[title], [], headers, ...rows]);
      const columnCount = headers.length;
      sheet['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: columnCount - 1 } }];
      sheet['!cols'] = widths.map(width => ({ wch: width }));
      sheet['!rows'] = [{ hpt: 26 }, { hpt: 8 }, { hpt: 24 }];
      sheet['!freeze'] = { xSplit: 0, ySplit: 3 };

      for (let row = 0; row <= rows.length + 2; row += 1) {
        for (let column = 0; column < columnCount; column += 1) {
          const cell = XLSX.utils.encode_cell({ r: row, c: column });
          if (!sheet[cell]) sheet[cell] = { v: '' };
          sheet[cell].s = row === 0 ? titleStyle : row === 2 ? headerStyle : dataStyle;
        }
      }

      for (let row = 3; row < rows.length + 3; row += 1) {
        for (let column = 0; column < columnCount; column += 1) {
          const cell = sheet[XLSX.utils.encode_cell({ r: row, c: column })];
          if (cell && (headers[column] === 'Total' || headers[column] === 'Harga')) cell.z = '#,##0';
        }
      }

      return sheet;
    };

    const workbook = XLSX.utils.book_new();
    const orderSheet = createSheet(
      'Laporan Pesanan',
      ['No. Pesanan', 'Pelanggan', 'Tanggal', 'Item', 'Total', 'Status'],
      adminOrders.map(order => [order.order_number, order.customer, order.date, order.items, order.total, order.status]),
      [20, 24, 16, 10, 16, 16],
    );
    const productSheet = createSheet(
      'Laporan Produk',
      ['ID', 'Produk', 'Kategori', 'Harga', 'Stok', 'Terjual'],
      productList.map(product => [product.id, product.name, product.category, product.price, product.stock, product.sold]),
      [10, 34, 20, 16, 12, 12],
    );
    XLSX.utils.book_append_sheet(workbook, orderSheet, 'Pesanan');
    XLSX.utils.book_append_sheet(workbook, productSheet, 'Produk');
    XLSX.writeFile(workbook, `laporan-wicaksono-${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleSaveSettings = () => {
    Object.entries(settings).forEach(([key, value]) => localStorage.setItem(key, value));
    window.alert('Pengaturan berhasil disimpan.');
  };

  const handleChangePassword = async () => {
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      window.alert('Lengkapi semua field password.');
      return;
    }

    if (passwordForm.newPassword.length < 8) {
      window.alert('Password baru minimal 8 karakter.');
      return;
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      window.alert('Konfirmasi password baru tidak cocok.');
      return;
    }

    try {
      await apiFetch('/auth/password', {
        method: 'PATCH',
        body: JSON.stringify({
          current_password: passwordForm.currentPassword,
          password: passwordForm.newPassword,
          password_confirmation: passwordForm.confirmPassword,
        }),
      });
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      window.alert('Password berhasil diubah.');
    } catch (error) {
      console.error('Gagal mengubah password:', error);
      window.alert(error instanceof Error ? error.message : 'Gagal mengubah password.');
    }
  };

  const menus = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'products', label: 'Produk', icon: '📦' },
    { id: 'categories', label: 'Kategori', icon: '🏷️' },
    { id: 'orders', label: 'Pesanan', icon: '🛒' },
    { id: 'customers', label: 'Pelanggan', icon: '👥' },
    { id: 'reports', label: 'Laporan', icon: '📈' },
    { id: 'settings', label: 'Pengaturan', icon: '⚙️' },
  ];

  const stats = [
    { label: 'Total Produk', value: dashboardSummary ? dashboardSummary.total_products.toLocaleString('id-ID') : '...', icon: '📦', color: '#F97316', bg: 'rgba(249,115,22,0.08)' },
    { label: 'Total Pesanan', value: dashboardSummary ? dashboardSummary.total_orders.toLocaleString('id-ID') : '...', icon: '🛒', color: '#16A34A', bg: 'rgba(22,163,74,0.08)' },
    { label: 'Pendapatan', value: dashboardSummary ? formatPrice(dashboardSummary.total_revenue) : '...', icon: '💰', color: '#FACC15', bg: 'rgba(250,204,21,0.1)' },
    { label: 'Pelanggan', value: dashboardSummary ? dashboardSummary.total_users.toLocaleString('id-ID') : '...', icon: '👥', color: '#8B5CF6', bg: 'rgba(139,92,246,0.08)' },
  ];

  const COLORS = ['#F97316', '#16A34A', '#FACC15', '#8B5CF6', '#EC4899'];
  const highestMonthlyRevenue = Math.max(...monthlySales.map(item => item.revenue), 0);
  const revenueAxisMax = Math.max(5000000, Math.ceil(highestMonthlyRevenue / 1000000) * 1000000);
  const revenueAxisTicks = Array.from({ length: revenueAxisMax / 1000000 + 1 }, (_, index) => index * 1000000);

  const formatIndonesianDate = (date: Date) =>
    new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date);

  const [currentDateLabel, setCurrentDateLabel] = useState(() => formatIndonesianDate(new Date()));
  const adminEmail = localStorage.getItem('userEmail') || 'admin@wicaksono.id';

  useEffect(() => {
    const updateDate = () => setCurrentDateLabel(formatIndonesianDate(new Date()));
    updateDate();

    const timer = window.setInterval(updateDate, 60000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="admin-shell" style={{ display: 'flex', minHeight: '100vh', background: '#F8F9FA' }}>
      {/* Sidebar */}
      <div className="admin-sidebar" style={{
        width: 240, background: '#1F2937', flexShrink: 0,
        display: 'flex', flexDirection: 'column', position: 'sticky', top: 0, height: '100vh',
      }}>
        {/* Logo */}
        <div style={{ padding: '20px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10,  display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
              <img src="/public/logobg.png" alt="Logo Wicaksono" style={{ width: 30, height: 30, objectFit: 'contain' }} />
            </div>
            <div>
              <div style={{ color: '#F97316', fontWeight: 800, fontSize: '0.9rem' }}>Wicaksono</div>
              <div style={{ color: '#6B7280', fontSize: '0.65rem' }}>Admin Panel</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '12px 0', overflowY: 'auto' }}>
          {menus.map(m => (
            <button key={m.id} onClick={() => setActiveMenu(m.id)} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              width: '100%', padding: '11px 20px', border: 'none',
              background: activeMenu === m.id ? 'rgba(249,115,22,0.15)' : 'transparent',
              borderLeft: `3px solid ${activeMenu === m.id ? '#F97316' : 'transparent'}`,
              color: activeMenu === m.id ? '#F97316' : '#9CA3AF',
              fontFamily: 'Poppins', fontWeight: activeMenu === m.id ? 700 : 400,
              fontSize: '0.85rem', cursor: 'pointer', textAlign: 'left', transition: 'all 0.2s',
            }}
            onMouseEnter={e => { if (activeMenu !== m.id) { (e.currentTarget as HTMLElement).style.color = '#E5E7EB'; (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)'; } }}
            onMouseLeave={e => { if (activeMenu !== m.id) { (e.currentTarget as HTMLElement).style.color = '#9CA3AF'; (e.currentTarget as HTMLElement).style.background = 'transparent'; } }}>
              <span style={{ fontSize: 16 }}>{m.icon}</span>
              {m.label}
            </button>
          ))}
        </nav>

        {/* Bottom */}
        <div style={{ padding: '16px 20px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#F97316', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: 'white' }}>A</div>
            <div>
              <div style={{ color: '#E5E7EB', fontSize: '0.82rem', fontWeight: 600 }}>Admin</div>
              <div style={{ color: '#6B7280', fontSize: '0.7rem' }}>{adminEmail}</div>
            </div>
          </div>
          <button onClick={() => navigate('home')} style={{
            width: '100%', padding: '8px', background: 'rgba(249,115,22,0.15)',
            border: 'none', borderRadius: 8, cursor: 'pointer',
            color: '#F97316', fontFamily: 'Poppins', fontSize: '0.8rem', fontWeight: 600,
          }}>← Lihat Toko</button>
        </div>
      </div>

      {/* Main content */}
      <div className="admin-content" style={{ flex: 1, padding: '28px 32px', overflowY: 'auto', maxHeight: '100vh' }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
          <div>
            <h1 style={{ margin: 0, fontSize: '1.6rem', fontWeight: 800, color: '#1F2937' }}>
              {menus.find(m => m.id === activeMenu)?.label}
            </h1>
            <p style={{ margin: '4px 0 0', color: '#6B7280', fontSize: '0.85rem' }}>
              {currentDateLabel}
            </p>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            {/* <button style={{ position: 'relative', background: 'white', border: '1px solid #E5E7EB', borderRadius: 10, padding: '8px 12px', cursor: 'pointer', fontSize: 18 }}>
              🔔
              <span style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: '50%', background: '#F97316' }} />
            </button> */}
            {activeMenu === 'products' && (
              <button
                className="btn-primary"
                onClick={openAddModal}
                style={{ padding: '9px 18px', fontSize: '0.85rem' }}
              >
                + Tambah Produk
              </button>
            )}
            {activeMenu === 'categories' && (
              <button
                className="btn-primary"
                onClick={handleAddCategory}
                style={{ padding: '9px 18px', fontSize: '0.85rem' }}
              >
                + Tambah Kategori
              </button>
            )}
          </div>
        </div>

        {/* Stats */}
        {activeMenu === 'dashboard' && (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
              {stats.map(s => (
                <div key={s.label} style={{
                  background: 'white', borderRadius: 14, padding: '20px',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.04)',
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <p style={{ margin: '0 0 8px', fontSize: '0.78rem', color: '#6B7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>{s.label}</p>
                      <p style={{ margin: 0, fontSize: '1.6rem', fontWeight: 900, color: '#1F2937' }}>{s.value}</p>
                    </div>
                    <div style={{ width: 44, height: 44, borderRadius: 12, background: s.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>{s.icon}</div>
                  </div>
                  <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 4 }}>
                    <span style={{ color: '#6B7280', fontSize: '0.78rem' }}>Data terkini dari database</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Charts row */}
            <div className="admin-content-grid" style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 24 }}>
              {/* Sales chart */}
              <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
                <h3 style={{ margin: '0 0 6px', fontWeight: 700, color: '#1F2937', fontSize: '1rem' }}>Pendapatan Bulanan</h3>
                <p style={{ margin: '0 0 20px', color: '#9CA3AF', fontSize: '0.75rem' }}>6 bulan mulai bulan sekarang</p>
                <ResponsiveContainer width="100%" height={190}>
                  <LineChart data={monthlySales}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
                    <XAxis dataKey="month" tick={{ fontFamily: 'Poppins', fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                    <YAxis domain={[0, revenueAxisMax]} ticks={revenueAxisTicks} tick={{ fontFamily: 'Poppins', fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} tickFormatter={value => `${value / 1000000}jt`} />
                    <Tooltip
                      contentStyle={{ fontFamily: 'Poppins', fontSize: 12, borderRadius: 10, border: '1px solid #F3F4F6', boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}
                      formatter={(value: unknown) => [formatPrice(value as number), 'Pendapatan']}
                    />
                    <Line type="monotone" dataKey="revenue" stroke="#F97316" strokeWidth={2.5} dot={{ fill: '#F97316', r: 4 }} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
                {!monthlySales.some(item => item.revenue > 0) && (
                  <div style={{ marginTop: 8, color: '#9CA3AF', fontSize: '0.75rem', textAlign: 'center' }}>Belum ada transaksi. Skala di atas adalah patokan pendapatan.</div>
                )}
              </div>

              {/* Pie chart */}
              <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
                <h3 style={{ margin: '0 0 6px', fontWeight: 700, color: '#1F2937', fontSize: '1rem' }}>Kategori Terlaris</h3>
                <p style={{ margin: '0 0 12px', color: '#9CA3AF', fontSize: '0.75rem' }}>Berdasarkan penjualan mulai bulan sekarang</p>
                {categorySales.length ? (
                  <>
                    <ResponsiveContainer width="100%" height={140}>
                      <PieChart>
                        <Pie data={categorySales} dataKey="sales" nameKey="name" cx="50%" cy="50%" outerRadius={60} innerRadius={32}>
                          {categorySales.map((_, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                        </Pie>
                        <Tooltip contentStyle={{ fontFamily: 'Poppins', fontSize: 12, borderRadius: 8 }} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                      {categorySales.slice(0, 3).map((category, index) => (
                        <div key={category.name} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <div style={{ width: 10, height: 10, borderRadius: 3, background: COLORS[index], flexShrink: 0 }} />
                          <span style={{ fontSize: '0.78rem', color: '#6B7280', flex: 1 }}>{category.name}</span>
                          <span style={{ fontSize: '0.78rem', fontWeight: 700, color: '#1F2937' }}>{category.sales.toLocaleString('id-ID')}</span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div style={{ height: 190, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px dashed #D1D5DB', borderRadius: 10, color: '#9CA3AF', fontSize: '0.8rem' }}>Belum ada data kategori.</div>
                )}
              </div>
            </div>

            {/* Bar chart + recent orders */}
            <div className="admin-content-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
                <h3 style={{ margin: '0 0 6px', fontWeight: 700, color: '#1F2937', fontSize: '1rem' }}>Jumlah Pesanan</h3>
                <p style={{ margin: '0 0 20px', color: '#9CA3AF', fontSize: '0.75rem' }}>6 bulan mulai bulan sekarang</p>
                {monthlySales.some(item => item.orders > 0) ? (
                  <ResponsiveContainer width="100%" height={190}>
                    <BarChart data={monthlySales}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
                      <XAxis dataKey="month" tick={{ fontFamily: 'Poppins', fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                      <YAxis allowDecimals={false} tick={{ fontFamily: 'Poppins', fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{ fontFamily: 'Poppins', fontSize: 12, borderRadius: 10, border: '1px solid #F3F4F6' }} />
                      <Bar dataKey="orders" fill="#16A34A" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div style={{ height: 190, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px dashed #D1D5DB', borderRadius: 10, color: '#9CA3AF', fontSize: '0.8rem' }}>Belum ada data pesanan.</div>
                )}
              </div>

              <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
                <h3 style={{ margin: '0 0 16px', fontWeight: 700, color: '#1F2937', fontSize: '1rem' }}>Pesanan Terbaru</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {adminOrders.slice(0, 4).map(order => {
                    const sc = statusColor(order.status);
                    return (
                      <div key={order.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #F9FAFB' }}>
                        <div>
                          <div style={{ fontWeight: 600, fontSize: '0.82rem', color: '#1F2937' }}>{order.order_number}</div>
                          <div style={{ fontSize: '0.72rem', color: '#9CA3AF' }}>{order.customer}</div>
                        </div>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                          <span style={{ fontWeight: 700, color: '#1F2937', fontSize: '0.82rem' }}>{formatPrice(order.total)}</span>
                          <span style={{ background: sc.bg, color: sc.text, borderRadius: 100, padding: '2px 8px', fontSize: '0.68rem', fontWeight: 700 }}>{orderStatusLabel(order.status)}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </>
        )}

        {activeMenu === 'products' && (
          <div style={{ background: 'white', borderRadius: 14, boxShadow: '0 2px 8px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
            {/* Table header */}
            <div style={{ padding: '16px 20px', borderBottom: '1px solid #F3F4F6', display: 'flex', gap: 12, alignItems: 'center' }}>
              <input className="input-field" placeholder="Cari produk..." style={{ maxWidth: 280 }} />
              <select className="input-field" style={{ width: 'auto' }}>
                <option>Semua Kategori</option>
                <option>Keripik</option>
                <option>Brownis</option>
                <option>Bakpia</option>
                <option>Pie</option>
                <option>Nastar</option>
                <option>Souvenir</option>
              </select>
              <button onClick={handleDeleteAllProducts} style={{ marginLeft: 'auto', padding: '8px 12px', borderRadius: 8, border: '1px solid #FECACA', background: '#FEF2F2', color: '#DC2626', cursor: 'pointer', fontFamily: 'Poppins', fontWeight: 600, fontSize: '0.75rem' }}>
                Hapus Semua
              </button>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table className="mobile-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#F9FAFB' }}>
                    {['Produk', 'Kategori', 'Harga', 'Stok', 'Terjual', 'Rating', 'Aksi'].map(h => (
                      <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: '0.78rem', fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.5 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {productList.map(p => (
                    <tr key={p.id} style={{ borderBottom: '1px solid #F9FAFB' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#FEFCE8'; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}>
                      <td style={{ padding: '12px 16px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <img src={p.image} alt="" style={{ width: 40, height: 40, borderRadius: 8, objectFit: 'cover', background: '#FFF8F0' }} />
                          <span style={{ fontWeight: 600, fontSize: '0.85rem', color: '#1F2937' }}>{p.name}</span>
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{ background: 'rgba(249,115,22,0.1)', color: '#F97316', borderRadius: 100, padding: '3px 10px', fontSize: '0.75rem', fontWeight: 600, textTransform: 'capitalize' }}>{p.category}</span>
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: 700, color: '#F97316', fontSize: '0.875rem' }}>{formatPrice(p.price)}</td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{ color: p.stock < 30 ? '#DC2626' : '#16A34A', fontWeight: 600, fontSize: '0.875rem' }}>{p.stock}</span>
                      </td>
                      <td style={{ padding: '12px 16px', color: '#6B7280', fontSize: '0.875rem' }}>{p.sold.toLocaleString()}</td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{ color: '#FACC15', fontWeight: 700 }}>★ </span>
                        <span style={{ color: '#1F2937', fontWeight: 600, fontSize: '0.875rem' }}>{p.rating}</span>
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button onClick={() => openEditModal(p)} style={{ padding: '5px 10px', borderRadius: 6, border: '1px solid #E5E7EB', background: 'white', cursor: 'pointer', fontSize: '0.75rem', fontFamily: 'Poppins' }}>Edit</button>
                          <button onClick={() => handleDeleteProduct(p)} style={{ padding: '5px 10px', borderRadius: 6, border: '1px solid #FEE2E2', background: '#FEF2F2', cursor: 'pointer', fontSize: '0.75rem', color: '#DC2626', fontFamily: 'Poppins' }}>Hapus</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeMenu === 'orders' && (
          <div style={{ background: 'white', borderRadius: 14, boxShadow: '0 2px 8px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
            <div style={{ padding: '16px 20px', borderBottom: '1px solid #F3F4F6', display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {['Semua', 'Diproses', 'Dikirim', 'Selesai', 'Batal'].map(s => (
                <button key={s} style={{
                  padding: '6px 14px', borderRadius: 100, border: 'none',
                  background: s === 'Semua' ? '#F97316' : '#F3F4F6',
                  color: s === 'Semua' ? 'white' : '#374151',
                  fontFamily: 'Poppins', fontWeight: 600, fontSize: '0.8rem', cursor: 'pointer',
                }}>{s}</button>
              ))}
              <button onClick={handleDeleteAllOrders} style={{ marginLeft: 'auto', padding: '6px 14px', borderRadius: 100, border: '1px solid #FECACA', background: '#FEF2F2', color: '#DC2626', fontFamily: 'Poppins', fontWeight: 600, fontSize: '0.8rem', cursor: 'pointer' }}>
                Hapus Semua Pesanan
              </button>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table className="mobile-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#F9FAFB' }}>
                    {['No. Pesanan', 'Pelanggan', 'Tanggal', 'Item', 'Total', 'Status', 'Aksi'].map(h => (
                      <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: '0.78rem', fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.5 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {adminOrders.map(o => {
                    const sc = statusColor(o.status);
                    return (
                      <tr key={o.id} style={{ borderBottom: '1px solid #F9FAFB' }}
                      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#F9FAFB'; }}
                      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}>
                        <td style={{ padding: '14px 16px', fontWeight: 700, color: '#F97316', fontSize: '0.875rem' }}>{o.order_number}</td>
                        <td style={{ padding: '14px 16px', fontWeight: 600, color: '#1F2937', fontSize: '0.875rem' }}>{o.customer}</td>
                        <td style={{ padding: '14px 16px', color: '#6B7280', fontSize: '0.875rem' }}>{o.date}</td>
                        <td style={{ padding: '14px 16px', color: '#6B7280', fontSize: '0.875rem' }}>{o.items} item</td>
                        <td style={{ padding: '14px 16px', fontWeight: 700, color: '#1F2937', fontSize: '0.875rem' }}>{formatPrice(o.total)}</td>
                        <td style={{ padding: '14px 16px' }}>
                          <span style={{ background: sc.bg, color: sc.text, borderRadius: 100, padding: '4px 12px', fontSize: '0.75rem', fontWeight: 700 }}>{orderStatusLabel(o.status)}</span>
                        </td>
                        <td style={{ padding: '14px 16px' }}>
                          <button onClick={() => handleViewOrderDetail(o)} disabled={isLoadingOrderDetail} style={{ padding: '5px 12px', borderRadius: 6, border: '1px solid #E5E7EB', background: 'white', cursor: isLoadingOrderDetail ? 'wait' : 'pointer', fontSize: '0.78rem', fontFamily: 'Poppins', fontWeight: 600 }}>{isLoadingOrderDetail ? 'Memuat...' : 'Detail'}</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeMenu === 'reports' && (
          <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16, marginBottom: 24 }}>
              <div>
                <h2 style={{ margin: 0, fontWeight: 800, color: '#1F2937' }}>Laporan</h2>
                <p style={{ margin: '4px 0 0', color: '#9CA3AF', fontSize: '0.85rem' }}>Data laporan diambil dari pesanan dan produk aktual.</p>
              </div>
              <button onClick={handleExportReport} className="btn-primary" style={{ padding: '9px 16px', fontSize: '0.8rem' }}>Unduh Excel</button>
            </div>
            {!productList.length && !adminOrders.length ? (
              <div style={{ padding: '56px 20px', textAlign: 'center', border: '1px dashed #D1D5DB', borderRadius: 10, color: '#9CA3AF' }}>
                Belum ada data laporan.
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
                <div style={{ padding: '16px', background: '#F9FAFB', borderRadius: 10 }}>
                  <div style={{ color: '#9CA3AF', fontSize: '0.75rem' }}>Data Pesanan</div>
                  <div style={{ color: '#1F2937', fontSize: '1.4rem', fontWeight: 800, marginTop: 4 }}>{adminOrders.length}</div>
                  <div style={{ color: '#6B7280', fontSize: '0.78rem', marginTop: 2 }}>pesanan tersedia untuk diekspor</div>
                </div>
                <div style={{ padding: '16px', background: '#F9FAFB', borderRadius: 10 }}>
                  <div style={{ color: '#9CA3AF', fontSize: '0.75rem' }}>Data Produk</div>
                  <div style={{ color: '#1F2937', fontSize: '1.4rem', fontWeight: 800, marginTop: 4 }}>{productList.length}</div>
                  <div style={{ color: '#6B7280', fontSize: '0.78rem', marginTop: 2 }}>produk tersedia untuk diekspor</div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeMenu === 'categories' && (
          <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <div>
                <h2 style={{ margin: 0, fontWeight: 800, color: '#1F2937' }}>Daftar Kategori</h2>
                <p style={{ margin: '4px 0 0', color: '#9CA3AF', fontSize: '0.85rem' }}>{categories.length} kategori tersedia</p>
              </div>
            </div>
            {categories.length === 0 ? (
              <div style={{ padding: '40px 20px', textAlign: 'center', color: '#9CA3AF' }}>
                Belum ada kategori.
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 12 }}>
                {categories.map(category => (
                  <div key={category.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '16px', border: '1px solid #F3F4F6', borderRadius: 10 }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: 'rgba(249,115,22,0.1)', color: '#F97316', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🏷️</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 700, color: '#1F2937' }}>{category.name}</div>
                      <div style={{ color: '#9CA3AF', fontSize: '0.75rem' }}>ID: {category.id}</div>
                    </div>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button onClick={() => handleEditCategory(category)} style={{ padding: '5px 9px', borderRadius: 6, border: '1px solid #E5E7EB', background: 'white', cursor: 'pointer', fontSize: '0.72rem', fontFamily: 'Poppins' }}>Edit</button>
                      <button onClick={() => handleDeleteCategory(category)} style={{ padding: '5px 9px', borderRadius: 6, border: '1px solid #FEE2E2', background: '#FEF2F2', cursor: 'pointer', fontSize: '0.72rem', color: '#DC2626', fontFamily: 'Poppins' }}>Hapus</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeMenu === 'customers' && (
          <div style={{ background: 'white', borderRadius: 14, boxShadow: '0 2px 8px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
            <div style={{ padding: '20px', borderBottom: '1px solid #F3F4F6' }}>
              <h2 style={{ margin: 0, fontWeight: 800, color: '#1F2937' }}>Data Pelanggan</h2>
              <p style={{ margin: '4px 0 0', color: '#9CA3AF', fontSize: '0.85rem' }}>{adminUsers.length} pengguna terdaftar</p>
            </div>
            {adminUsers.length === 0 ? (
              <div style={{ padding: '48px 20px', textAlign: 'center', color: '#9CA3AF' }}>Belum ada data pelanggan.</div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table className="mobile-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: '#F9FAFB' }}>
                      {['Pengguna', 'Kontak', 'Role', 'Bergabung', 'Aktivitas', 'Aksi'].map(header => (
                        <th key={header} style={{ padding: '12px 16px', textAlign: 'left', fontSize: '0.78rem', fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.5 }}>{header}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {adminUsers.map(user => (
                      <tr key={user.id} style={{ borderBottom: '1px solid #F9FAFB' }}
                        onMouseEnter={event => { (event.currentTarget as HTMLElement).style.background = '#F9FAFB'; }}
                        onMouseLeave={event => { (event.currentTarget as HTMLElement).style.background = 'transparent'; }}>
                        <td style={{ padding: '14px 16px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#FFF1E8', color: '#F97316', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800 }}>
                              {(user.name || 'P').charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div style={{ fontWeight: 700, color: '#1F2937', fontSize: '0.85rem' }}>{user.name}</div>
                              <div style={{ color: '#9CA3AF', fontSize: '0.72rem' }}>ID: {user.id}</div>
                            </div>
                          </div>
                        </td>
                        <td style={{ padding: '14px 16px', color: '#6B7280', fontSize: '0.8rem' }}>
                          <div>{user.email}</div>
                          <div style={{ color: '#9CA3AF', marginTop: 3 }}>{user.phone || 'Nomor belum diisi'}</div>
                        </td>
                        <td style={{ padding: '14px 16px' }}>
                          <span style={{ background: user.role === 'admin' ? '#FEF3C7' : '#ECFDF5', color: user.role === 'admin' ? '#D97706' : '#16A34A', borderRadius: 100, padding: '4px 10px', fontSize: '0.72rem', fontWeight: 700, textTransform: 'capitalize' }}>{user.role}</span>
                        </td>
                        <td style={{ padding: '14px 16px', color: '#6B7280', fontSize: '0.8rem' }}>
                          {user.created_at ? new Intl.DateTimeFormat('id-ID').format(new Date(user.created_at)) : '-'}
                        </td>
                        <td style={{ padding: '14px 16px', color: '#6B7280', fontSize: '0.78rem' }}>
                          <div>{user.orders_count} pesanan</div>
                          <div>{user.reviews_count} ulasan · {user.addresses_count} alamat</div>
                        </td>
                        <td style={{ padding: '14px 16px' }}>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button onClick={() => handleViewUserHistory(user)} style={{ padding: '5px 10px', borderRadius: 6, border: '1px solid #E5E7EB', background: 'white', cursor: 'pointer', fontSize: '0.75rem', fontFamily: 'Poppins' }}>Riwayat</button>
                            <button onClick={() => handleDeleteUser(user)} style={{ padding: '5px 10px', borderRadius: 6, border: '1px solid #FEE2E2', background: '#FEF2F2', cursor: 'pointer', fontSize: '0.75rem', color: '#DC2626', fontFamily: 'Poppins' }}>Hapus</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeMenu === 'settings' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
              <h2 style={{ margin: '0 0 4px', fontWeight: 800, color: '#1F2937' }}>Profil Toko</h2>
              <p style={{ margin: '0 0 20px', color: '#9CA3AF', fontSize: '0.82rem' }}>Informasi yang digunakan pada halaman toko.</p>
              {[
                ['storeName', 'Nama Toko', 'Wicaksono'],
                ['storeEmail', 'Email Toko', 'admin@wicaksono.id'],
                ['storePhone', 'Nomor Telepon', '08xxxxxxxxxx'],
              ].map(([field, label, placeholder]) => (
                <div key={field} style={{ marginBottom: 16 }}>
                  <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>{label}</label>
                  <input value={settings[field as keyof typeof settings]} onChange={event => setSettings(prev => ({ ...prev, [field]: event.target.value }))} placeholder={placeholder} className="input-field" />
                </div>
              ))}
              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Alamat Toko</label>
                <textarea value={settings.storeAddress} onChange={event => setSettings(prev => ({ ...prev, storeAddress: event.target.value }))} placeholder="Masukkan alamat toko" className="input-field" rows={4} style={{ resize: 'vertical' }} />
              </div>
            </div>

            <div style={{ background: 'white', borderRadius: 14, padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)', height: 'fit-content' }}>
              <h2 style={{ margin: '0 0 4px', fontWeight: 800, color: '#1F2937' }}>Profil Admin</h2>
              <p style={{ margin: '0 0 20px', color: '#9CA3AF', fontSize: '0.82rem' }}>Nama tampilan admin pada panel.</p>
              <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Nama Admin</label>
              <input value={settings.adminName} onChange={event => setSettings(prev => ({ ...prev, adminName: event.target.value }))} placeholder="Nama admin" className="input-field" />
              <button onClick={handleSaveSettings} className="btn-primary" style={{ marginTop: 20, padding: '10px 18px' }}>Simpan Pengaturan</button>

              <div style={{ borderTop: '1px solid #F3F4F6', marginTop: 24, paddingTop: 20 }}>
                <h3 style={{ margin: '0 0 4px', fontWeight: 700, color: '#1F2937', fontSize: '1rem' }}>Ganti Password</h3>
                <p style={{ margin: '0 0 16px', color: '#9CA3AF', fontSize: '0.78rem' }}>Gunakan minimal 8 karakter untuk password baru.</p>
                {[
                  ['currentPassword', 'Password Saat Ini', 'Masukkan password saat ini'],
                  ['newPassword', 'Password Baru', 'Masukkan password baru'],
                  ['confirmPassword', 'Konfirmasi Password Baru', 'Ulangi password baru'],
                ].map(([field, label, placeholder]) => (
                  <div key={field} style={{ marginBottom: 12 }}>
                    <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.82rem' }}>{label}</label>
                    <input type="password" value={passwordForm[field as keyof typeof passwordForm]} onChange={event => setPasswordForm(prev => ({ ...prev, [field]: event.target.value }))} placeholder={placeholder} className="input-field" />
                  </div>
                ))}
                <button onClick={handleChangePassword} style={{ padding: '10px 18px', borderRadius: 10, border: '1px solid #F97316', background: 'white', color: '#F97316', cursor: 'pointer', fontWeight: 700 }}>Ubah Password</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {selectedOrder && (
        <div className="mobile-modal" style={{ position: 'fixed', inset: 0, background: 'rgba(17,24,39,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, zIndex: 1000 }}>
          <div style={{ width: '100%', maxWidth: 720, maxHeight: '90vh', overflowY: 'auto', background: 'white', borderRadius: 18, padding: 24, boxShadow: '0 16px 40px rgba(0,0,0,0.18)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <h2 style={{ margin: 0, color: '#1F2937', fontWeight: 800 }}>Detail Pesanan</h2>
                <p style={{ margin: '4px 0 0', color: '#9CA3AF', fontSize: '0.8rem' }}>{selectedOrder.order_number} · {selectedOrder.date} · {selectedOrder.customer}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} style={{ border: 'none', background: '#F3F4F6', width: 34, height: 34, borderRadius: 8, cursor: 'pointer', fontSize: 18, color: '#374151' }}>×</button>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 14px', background: '#F9FAFB', borderRadius: 10, marginBottom: 18 }}>
              <span style={{ color: '#6B7280', fontSize: '0.82rem' }}>Status Pesanan</span>
              <span style={{ background: statusColor(selectedOrder.status).bg, color: statusColor(selectedOrder.status).text, borderRadius: 100, padding: '4px 12px', fontSize: '0.75rem', fontWeight: 700 }}>{orderStatusLabel(selectedOrder.status)}</span>
            </div>

            <h3 style={{ margin: '0 0 10px', color: '#1F2937', fontSize: '1rem' }}>Produk Dipesan</h3>
            <div style={{ border: '1px solid #F3F4F6', borderRadius: 10, overflow: 'hidden' }}>
              {selectedOrder.items_detail.length ? selectedOrder.items_detail.map(item => (
                <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', gap: 12, padding: '12px 14px', borderBottom: '1px solid #F9FAFB' }}>
                  <div>
                    <div style={{ color: '#1F2937', fontWeight: 600, fontSize: '0.85rem' }}>{item.product_name}</div>
                    <div style={{ color: '#9CA3AF', fontSize: '0.75rem', marginTop: 3 }}>{item.quantity} x {formatPrice(item.price)}</div>
                  </div>
                  <span style={{ color: '#1F2937', fontWeight: 700, fontSize: '0.85rem' }}>{formatPrice(item.subtotal)}</span>
                </div>
              )) : <div style={{ padding: 16, color: '#9CA3AF', fontSize: '0.8rem' }}>Detail produk tidak tersedia.</div>}
            </div>

            <div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <h3 style={{ margin: '0 0 8px', color: '#1F2937', fontSize: '1rem' }}>Pengiriman</h3>
                <div style={{ color: '#6B7280', fontSize: '0.8rem', lineHeight: 1.6 }}>
                  <strong style={{ color: '#374151' }}>{selectedOrder.shipping_name || '-'}</strong><br />
                  {selectedOrder.shipping_phone || '-'}<br />
                  {selectedOrder.shipping_address || '-'}, {selectedOrder.shipping_city || '-'}, {selectedOrder.shipping_province || '-'} {selectedOrder.shipping_postal_code || ''}<br />
                  Kurir: {selectedOrder.shipping_method?.name || '-'}
                </div>
              </div>
              <div>
                <h3 style={{ margin: '0 0 8px', color: '#1F2937', fontSize: '1rem' }}>Pembayaran</h3>
                <div style={{ color: '#6B7280', fontSize: '0.8rem', lineHeight: 1.6 }}>
                  Metode: {selectedOrder.payment?.method || '-'}<br />
                  Status: {selectedOrder.payment?.status || '-'}<br />
                  Subtotal: {formatPrice(selectedOrder.subtotal || 0)}<br />
                  Pengiriman: {formatPrice(selectedOrder.shipping_cost || 0)}<br />
                  <strong style={{ color: '#F97316' }}>Total: {formatPrice(selectedOrder.total)}</strong>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 24, paddingTop: 18, borderTop: '1px solid #F3F4F6' }}>
              {({ pending: ['confirmed', 'cancelled'], confirmed: ['processing', 'cancelled'], processing: ['shipped'], shipped: ['completed'] }[selectedOrder.status] ?? []).map(nextStatus => (
                <button key={nextStatus} onClick={() => handleUpdateOrderStatus(nextStatus)} disabled={isUpdatingOrderStatus} className="btn-primary" style={{ padding: '10px 16px' }}>
                  {isUpdatingOrderStatus ? 'Menyimpan...' : `Ubah ke ${orderStatusLabel(nextStatus)}`}
                </button>
              ))}
              <button onClick={() => setSelectedOrder(null)} className="btn-outline" style={{ padding: '10px 20px' }}>Tutup</button>
            </div>
          </div>
        </div>
      )}

      {selectedUser && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(17,24,39,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, zIndex: 1000 }}>
          <div style={{ width: '100%', maxWidth: 720, maxHeight: '90vh', overflowY: 'auto', background: 'white', borderRadius: 18, padding: 24, boxShadow: '0 16px 40px rgba(0,0,0,0.18)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <h2 style={{ margin: 0, fontSize: '1.3rem', fontWeight: 800, color: '#1F2937' }}>Riwayat Pengguna</h2>
                <p style={{ margin: '4px 0 0', color: '#9CA3AF', fontSize: '0.8rem' }}>Detail aktivitas {selectedUser.name}</p>
              </div>
              <button onClick={() => setSelectedUser(null)} style={{ border: 'none', background: '#F3F4F6', width: 34, height: 34, borderRadius: 8, cursor: 'pointer', fontSize: 18, color: '#374151' }}>×</button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 20 }}>
              {[
                { label: 'Pesanan', value: selectedUser.orders_count },
                { label: 'Ulasan', value: selectedUser.reviews_count },
                { label: 'Alamat', value: selectedUser.addresses_count },
              ].map(item => (
                <div key={item.label} style={{ background: '#F9FAFB', borderRadius: 10, padding: '12px 14px' }}>
                  <div style={{ color: '#9CA3AF', fontSize: '0.72rem' }}>{item.label}</div>
                  <div style={{ marginTop: 3, color: '#1F2937', fontWeight: 800, fontSize: '1.1rem' }}>{item.value}</div>
                </div>
              ))}
            </div>

            <div style={{ padding: '14px 16px', border: '1px solid #F3F4F6', borderRadius: 10, marginBottom: 20 }}>
              <div style={{ fontWeight: 700, color: '#1F2937', marginBottom: 8 }}>{selectedUser.name}</div>
              <div style={{ color: '#6B7280', fontSize: '0.82rem' }}>{selectedUser.email}</div>
              <div style={{ color: '#6B7280', fontSize: '0.82rem', marginTop: 4 }}>{selectedUser.phone || 'Nomor telepon belum diisi'}</div>
            </div>

            <h3 style={{ margin: '0 0 12px', fontSize: '1rem', color: '#1F2937' }}>Pesanan Terakhir</h3>
            {selectedUser.orders?.length ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {selectedUser.orders.map(order => {
                  const orderStatus = typeof order.order_status === 'string' ? order.order_status : order.order_status?.value || 'pending';
                  const orderStatusStyle = statusColor(orderStatus);
                  return (
                    <div key={order.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: '1px solid #F9FAFB' }}>
                      <div>
                        <div style={{ color: '#F97316', fontWeight: 700, fontSize: '0.82rem' }}>{order.order_number}</div>
                        <div style={{ color: '#9CA3AF', fontSize: '0.72rem', marginTop: 3 }}>{order.created_at ? new Intl.DateTimeFormat('id-ID').format(new Date(order.created_at)) : '-'}</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ color: '#1F2937', fontWeight: 700, fontSize: '0.82rem' }}>{formatPrice(Number(order.total || 0))}</span>
                        <span style={{ background: orderStatusStyle.bg, color: orderStatusStyle.text, borderRadius: 100, padding: '3px 8px', fontSize: '0.68rem', fontWeight: 700 }}>{orderStatusLabel(orderStatus)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div style={{ padding: '24px 0', color: '#9CA3AF', fontSize: '0.82rem', textAlign: 'center' }}>Belum ada riwayat pesanan.</div>
            )}

            {!!selectedUser.addresses?.length && (
              <>
                <h3 style={{ margin: '20px 0 12px', fontSize: '1rem', color: '#1F2937' }}>Alamat Tersimpan</h3>
                {selectedUser.addresses.map(address => (
                  <div key={address.id} style={{ padding: '10px 12px', background: '#F9FAFB', borderRadius: 8, color: '#6B7280', fontSize: '0.8rem', marginBottom: 6 }}>
                    <strong style={{ color: '#374151' }}>{address.label || 'Alamat'}</strong><br />
                    {address.address || '-'}{address.city ? `, ${address.city}` : ''}
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      )}

      {showAddModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(17,24,39,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, zIndex: 1000 }}>
          <div style={{ width: '100%', maxWidth: 720, background: 'white', borderRadius: 18, padding: 24, boxShadow: '0 16px 40px rgba(0,0,0,0.18)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h2 style={{ margin: 0, fontSize: '1.4rem', fontWeight: 800, color: '#1F2937' }}>{editingProductId ? 'Edit Produk' : 'Tambah Produk Baru'}</h2>
              <button onClick={() => setShowAddModal(false)} style={{ border: 'none', background: '#F3F4F6', width: 34, height: 34, borderRadius: 8, cursor: 'pointer', fontSize: 18, color: '#374151' }}>×</button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: 20 }}>
              <div>
                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Nama Produk</label>
                  <input value={newProduct.name} onChange={(e) => handleAddProductInput('name', e.target.value)} placeholder="Masukkan nama produk" className="input-field" />
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Kategori</label>
                  <select value={newProduct.categoryId} onChange={(e) => handleAddProductInput('categoryId', e.target.value)} className="input-field">
                    {categories.length === 0 ? (
                      <option value="">Memuat kategori...</option>
                    ) : (
                      categories.map(category => (
                        <option key={category.id} value={String(category.id)}>{category.name}</option>
                      ))
                    )}
                  </select>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Harga</label>
                    <input type="number" min="0" value={newProduct.price} onChange={(e) => handleAddProductInput('price', e.target.value)} placeholder="25000" className="input-field" />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Stok</label>
                    <input type="number" min="0" value={newProduct.stock} onChange={(e) => handleAddProductInput('stock', e.target.value)} placeholder="50" className="input-field" />
                  </div>
                </div>

                <div>
                  <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Deskripsi</label>
                  <textarea value={newProduct.description} onChange={(e) => handleAddProductInput('description', e.target.value)} rows={5} placeholder="Tuliskan deskripsi produk..." className="input-field" style={{ resize: 'vertical', minHeight: 120 }} />
                </div>
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 600, color: '#374151', fontSize: '0.85rem' }}>Foto Produk</label>
                <div style={{ width: '100%', minHeight: 220, border: '2px dashed #E5E7EB', borderRadius: 12, background: '#FFF8F0', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 12 }}>
                  {imagePreview ? (
                    <img src={imagePreview} alt="Preview produk" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <div style={{ textAlign: 'center', color: '#9CA3AF', padding: 20 }}>
                      <div style={{ fontSize: 32, marginBottom: 8 }}>🖼️</div>
                      <div style={{ fontSize: '0.8rem' }}>Belum ada gambar</div>
                    </div>
                  )}
                </div>

                <input type="file" accept="image/*" onChange={handleImageUpload} style={{ width: '100%', padding: '10px 12px', border: '1px solid #E5E7EB', borderRadius: 10, background: '#fff' }} />
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 24 }}>
              <button onClick={() => setShowAddModal(false)} style={{ padding: '10px 18px', borderRadius: 10, border: '1px solid #E5E7EB', background: 'white', cursor: 'pointer', fontWeight: 600, color: '#374151' }}>Batal</button>
              <button onClick={handleSaveProduct} className="btn-primary" style={{ padding: '10px 18px' }}>{editingProductId ? 'Simpan Perubahan' : 'Simpan Produk'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
