import { useEffect, useState } from 'react';

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  stock: number;
  sold: number;
  rating: number;
  description: string;
  image: string;
}

interface CategoryPageProps {
  category: string;
  navigate: (page: any) => void;
}

export function CategoryPage({
  category,
  navigate,
}: CategoryPageProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const API_URL = 'http://127.0.0.1:8000/api';

  useEffect(() => {
    fetch(`${API_URL}/products`)
      .then((response) => response.json())
      .then((data) => {
        const productData = Array.isArray(data)
          ? data
          : data.data || [];

        const filteredProducts = productData.filter(
          (product: Product) =>
            product.category?.toLowerCase() === category.toLowerCase()
        );

        setProducts(filteredProducts);
      })
      .catch((error) => {
        console.error('Gagal mengambil produk:', error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [category]);

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#FFF8F0',
        padding: '30px 20px 60px',
      }}
    >

      {/* HEADER */}
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto 30px',
        }}
      >
        <button
          onClick={() => navigate('catalog')}
          style={{
            border: 'none',
            background: 'white',
            padding: '10px 16px',
            borderRadius: 10,
            cursor: 'pointer',
            fontWeight: 600,
            color: '#F97316',
            marginBottom: 20,
          }}
        >
          ← Kembali
        </button>

        <h1
          style={{
            margin: 0,
            fontSize: 'clamp(1.7rem, 4vw, 2.5rem)',
            fontWeight: 800,
            color: '#1F2937',
          }}
        >
          Produk {category}
        </h1>

        <p
          style={{
            marginTop: 8,
            color: '#6B7280',
          }}
        >
          Temukan berbagai pilihan {category} khas Malang.
        </p>
      </div>

      {/* PRODUCT */}
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto',
        }}
      >

        {loading ? (
          <div
            style={{
              textAlign: 'center',
              padding: 50,
              color: '#6B7280',
            }}
          >
            Memuat produk...
          </div>
        ) : products.length === 0 ? (
          <div
            style={{
              background: 'white',
              borderRadius: 16,
              padding: 50,
              textAlign: 'center',
            }}
          >
            <div style={{ fontSize: 50 }}>
              📦
            </div>

            <h3>
              Produk belum tersedia
            </h3>

            <p style={{ color: '#6B7280' }}>
              Belum ada produk untuk kategori {category}.
            </p>
          </div>
        ) : (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns:
                'repeat(auto-fill, minmax(200px, 1fr))',
              gap: 20,
            }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                style={{
                  background: 'white',
                  borderRadius: 16,
                  overflow: 'hidden',
                  border: '1px solid #F3F4F6',
                  boxShadow:
                    '0 4px 15px rgba(0,0,0,0.06)',
                }}
              >

                {/* IMAGE */}
                <div
                  style={{
                    width: '100%',
                    height: 200,
                    background: '#F9FAFB',
                  }}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                    }}
                  />
                </div>

                {/* INFO */}
                <div
                  style={{
                    padding: 16,
                  }}
                >
                  <h3
                    style={{
                      margin: '0 0 8px',
                      fontSize: '1rem',
                      color: '#1F2937',
                    }}
                  >
                    {product.name}
                  </h3>

                  <div
                    style={{
                      color: '#F97316',
                      fontWeight: 800,
                      fontSize: '1.05rem',
                    }}
                  >
                    Rp{' '}
                    {Number(product.price).toLocaleString(
                      'id-ID'
                    )}
                  </div>

                  <div
                    style={{
                      marginTop: 8,
                      fontSize: '0.8rem',
                      color: '#6B7280',
                    }}
                  >
                    ⭐ {product.rating || 0}
                    {' · '}
                    Terjual {product.sold || 0}
                  </div>

                  <button
                    style={{
                      width: '100%',
                      marginTop: 14,
                      padding: '10px',
                      border: 'none',
                      borderRadius: 10,
                      background: '#F97316',
                      color: 'white',
                      fontWeight: 700,
                      cursor: 'pointer',
                    }}
                  >
                    🛒 Tambah ke Keranjang
                  </button>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
}