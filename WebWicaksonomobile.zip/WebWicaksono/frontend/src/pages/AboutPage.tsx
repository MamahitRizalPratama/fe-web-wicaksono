import type { Page } from '../App';

interface AboutPageProps {
  navigate: (page: Page, data?: unknown) => void;
}

export default function AboutPage({ navigate }: AboutPageProps) {
  return (
    <div className="mobile-page" style={{ maxWidth: 1280, margin: '0 auto', padding: '60px 24px' }}>
      <h1 style={{ 
        fontSize: '2.5rem', 
        fontWeight: 900, 
        color: '#1F2937',
        marginBottom: 24,
        textAlign: 'center'
      }}>
        Tentang Kami
      </h1>
      
      <div className="about-layout" style={{ 
        display: 'grid', 
        gridTemplateColumns: '1fr 1fr', 
        gap: 40,
        alignItems: 'center',
        marginTop: 40
      }}>
        <div>
          <img 
            src="/public/gambar.jpg" 
            alt="Tentang Wicaksono" 
            style={{ 
              width: '100%', 
              height: 400, 
              objectFit: 'cover', 
              borderRadius: 16 
            }} 
          />
        </div>
        <div>
          <h2 style={{ fontSize: '1.8rem', fontWeight: 800, color: '#F97316', marginBottom: 16 }}>
            Wicaksono Oleh-Oleh Khas Malang
          </h2>
          <p style={{ fontSize: '1rem', color: '#4B5563', lineHeight: 1.8, marginBottom: 16 }}>
            Wicaksono adalah pusat oleh-oleh khas Malang yang telah dipercaya sejak tahun 2005. 
            Kami berkomitmen untuk menyajikan produk-produk berkualitas tinggi dengan cita rasa autentik 
            khas Malang.
          </p>
          <p style={{ fontSize: '1rem', color: '#4B5563', lineHeight: 1.8, marginBottom: 16 }}>
            Dari keripik tempe yang renyah hingga apel segar yang manis, setiap produk kami dipilih 
            dengan teliti untuk memastikan kepuasan pelanggan.
          </p>
        </div>
      </div>

      {/* Visi Misi */}
      <div className="about-values" style={{ 
        display: 'grid', 
        gridTemplateColumns: '1fr 1fr 1fr', 
        gap: 24,
        marginTop: 60,
        paddingTop: 40,
        borderTop: '2px solid #F3F4F6'
      }}>
        <div style={{ textAlign: 'center', padding: 24, background: '#FFF8F0', borderRadius: 12 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🎯</div>
          <h3 style={{ fontWeight: 700, color: '#1F2937', marginBottom: 8 }}>Visi</h3>
          <p style={{ fontSize: '0.9rem', color: '#6B7280' }}>
            Menjadi pusat oleh-oleh terbaik yang melestarikan cita rasa khas Malang.
          </p>
        </div>
        <div style={{ textAlign: 'center', padding: 24, background: '#FFF8F0', borderRadius: 12 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>💡</div>
          <h3 style={{ fontWeight: 700, color: '#1F2937', marginBottom: 8 }}>Misi</h3>
          <p style={{ fontSize: '0.9rem', color: '#6B7280' }}>
            Menyediakan produk berkualitas dengan harga terjangkau untuk semua.
          </p>
        </div>
        <div style={{ textAlign: 'center', padding: 24, background: '#FFF8F0', borderRadius: 12 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>❤️</div>
          <h3 style={{ fontWeight: 700, color: '#1F2937', marginBottom: 8 }}>Nilai</h3>
          <p style={{ fontSize: '0.9rem', color: '#6B7280' }}>
            Kepercayaan, kualitas, dan kepuasan pelanggan adalah prioritas kami.
          </p>
        </div>
      </div>
    </div>
  );
}