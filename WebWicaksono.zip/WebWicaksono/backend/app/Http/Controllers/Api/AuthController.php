<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Register user baru.
     *
     * POST /api/auth/register
     */
    public function register(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:255',
            ],

            'email' => [
                'required',
                'email',
                'max:255',
                'unique:users,email',
            ],

            'phone' => [
                'nullable',
                'string',
                'max:20',
            ],

            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
            ],
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'] ?? null,
            'password' => $validated['password'],
            'role' => 'user',
        ]);

        // Buat token Sanctum
        $token = $user->createToken(
            'wicaksono-app'
        )->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Registrasi berhasil.',
            'data' => [
                'user' => $this->userData($user),
                'token' => $token,
            ],
        ], 201);
    }

    /**
     * Login.
     *
     * POST /api/auth/login
     */
    public function login(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'email' => [
                'required',
                'email',
            ],

            'password' => [
                'required',
                'string',
            ],
        ]);

        $user = User::where(
            'email',
            $validated['email']
        )->first();

        if (!$user) {
            throw ValidationException::withMessages([
                'email' => [
                    'Email belum terdaftar. Silakan daftar dulu sebelum login.',
                ],
            ]);
        }

        if (!Hash::check($validated['password'], $user->password)) {
            throw ValidationException::withMessages([
                'email' => [
                    'Email atau password salah.',
                ],
            ]);
        }

        // Hapus token lama jika diperlukan.
        // Untuk sekarang kita bersihkan token lama
        // agar satu login menghasilkan satu token aktif.
        $user->tokens()->delete();

        $token = $user->createToken(
            'wicaksono-app'
        )->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Login berhasil.',
            'data' => [
                'user' => $this->userData($user),
                'token' => $token,
            ],
        ]);
    }

    /**
     * Login atau register menggunakan credential Google.
     *
     * POST /api/auth/google
     */
    public function google(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'credential' => ['required', 'string'],
        ]);

        $googleResponse = Http::acceptJson()->get('https://oauth2.googleapis.com/tokeninfo', [
            'id_token' => $validated['credential'],
        ]);

        if (!$googleResponse->successful()) {
            throw ValidationException::withMessages([
                'credential' => ['Credential Google tidak valid atau sudah kedaluwarsa.'],
            ]);
        }

        $googleUser = $googleResponse->json();
        $configuredClientId = config('services.google.client_id');

        if (!$configuredClientId || ($googleUser['aud'] ?? null) !== $configuredClientId) {
            throw ValidationException::withMessages([
                'credential' => ['Client ID Google tidak cocok dengan konfigurasi aplikasi.'],
            ]);
        }

        $email = strtolower((string) ($googleUser['email'] ?? ''));
        if (!$email || ($googleUser['email_verified'] ?? 'false') !== 'true') {
            throw ValidationException::withMessages([
                'credential' => ['Email Google belum terverifikasi.'],
            ]);
        }

        $user = User::firstOrCreate(
            ['email' => $email],
            [
                'name' => $googleUser['name'] ?? Str::before($email, '@'),
                'password' => Hash::make(Str::random(40)),
                'email_verified_at' => now(),
                'role' => 'user',
            ]
        );

        $user->tokens()->delete();
        $token = $user->createToken('wicaksono-app')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Login Google berhasil.',
            'data' => [
                'user' => $this->userData($user),
                'token' => $token,
            ],
        ]);
    }

    /**
     * Mendapatkan user yang sedang login.
     *
     * GET /api/auth/me
     */
    public function me(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'success' => true,
            'message' => 'Data user berhasil diambil.',
            'data' => [
                'user' => $this->userData($user),
            ],
        ]);
    }

    /**
     * Logout.
     *
     * POST /api/auth/logout
     */
    public function logout(Request $request): JsonResponse
    {
        $token = $request->user()->currentAccessToken();

        if ($token && method_exists($token, 'delete')) {
            $token->delete();
        }

        return response()->json([
            'success' => true,
            'message' => 'Logout berhasil.',
        ]);
    }

    /**
     * Format response user.
     */
    private function userData(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'role' => $user->role->value,
        ];
    }
}